from setuptools import setup, find_packages
import os

with open('requirements.txt') as f:
    requierd = f.read().splitlines()
requirements =[
'biopython >=1.76',]

setup(
    name="homopolish",
    version="0.0.1",
    url='https://github.com/ythuang0522/homopolish',
    author='ythuang0522',
    packages=find_packages(),
    package_data={'homopolish':['R10.3.pkl','R9.4.pkl']},
    install_requires=requierd,
    entry_points={'console_scripts': ['homopolish =homopolish.homopolish:main']},
    )
